#!/usr/bin/env python3
def greet_function():
    print("Welcome to the Brain Games!")


def main():
    greet_function()


if __name__ == 'main':
    main()
