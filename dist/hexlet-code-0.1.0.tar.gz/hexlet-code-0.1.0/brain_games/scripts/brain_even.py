from brain_games.bre import brain_even


def main():
    brain_even()


if __name__ == 'main':
    main()
