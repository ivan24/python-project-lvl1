from brain_games.nod import brain_gcd


def main():
    brain_gcd()


if __name__ == "main":
    main()
