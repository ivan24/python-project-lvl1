from brain_games.prime import brain_prime


def main():
    brain_prime()


if __name__ == "main":
    main()
