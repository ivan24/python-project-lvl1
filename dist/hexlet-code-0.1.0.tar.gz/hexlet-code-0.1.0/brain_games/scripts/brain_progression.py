from brain_games.pro import brain_pro


def main():
    brain_pro()


if __name__ == "main":
    main()
