from brain_games.calc import brain_calc


def main():
    brain_calc()


if __name__ == 'main':
    main()
